/* I want to create a simple program that takes in some text and returns it in a different font.
 * 
 */
package wna.altervista.org;

import java.util.Scanner;


public class FontManipulation {

	public static void main(String[] args) {
		System.out.println("Please enter your name: ");
		String userInput = new Scanner(System.in).nextLine();
		
		String fontChanged = changeFont(userInput);
		
		System.out.println(fontChanged);
		
	}
	
	// Change font
	
	private static String changeFont(String userInput) {
		// Change font method.
		
		String result = "";
		 
		return result;
	}
	

	

}
