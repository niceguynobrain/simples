/* I want to create a simple program to show betting pattern results.
 * 
 * increase bet amount for every successful bet.
 * 
 * show how much will have if lost on any hand of a streak.
 * 
 * 		want to add a way to compare how many loosing hands would need how long a streak to be in profit.
 * 		
 * 		also add way to increase and decrease value of betting in play.
 * 
 */

package wna.altervista.org;

import java.util.Scanner;

public class BlachjackBetting {

	private static int betAmount;
	private static int count;
	private static String nameOfBet;
	private static String text;

	public static void main(String[] args) {
		Scanner choice = new Scanner(System.in);
		System.out.println("Please choose how you would like to bet. \n You can choose to go \"UP\" or \"DOWN\" \n Type UP to enter a first bet of 10 pence and increase bets by 10p a time. \n Type DOWN to enter a first bet of �1 and decrease 10p a time \n You could also choose to always DOUBLE your bet. \n Your choice: ");
		text = choice.nextLine();


		System.out.println("Enter first bet (in pence): ");
		int userInput = new Scanner(System.in).nextInt();

		int firstBet = userInput;
		betAmount = firstBet;
		System.out.println("\nFirst Bet ");
		System.out.println("Bet: " + betAmount);
		int bank = 0;
		bank = (bank - betAmount);
		System.out.println("bank: " + bank);
		int winnings = (betAmount * 2);
		System.out.println("Win: " + winnings);
		int newBank = bank + winnings;
		System.out.println("New Bank: " + newBank);
		
		System.out.printf("\n %-10s %10s %10s %10s %10s \r", "nameOfBet", "betAmount", "bank", "winnings", "newBank");

		for (int i = 0; i < 9; i++) {
			// System.out.println(betName() + "Bet: ");
			betAmount = betAmount + betChange();
			// System.out.println("Bet: " + betAmount);
			bank = (newBank - betAmount);
			// System.out.println("bank: " + bank);
			winnings = (betAmount * 2);
			// System.out.println("Win: " + winnings);
			newBank = bank + winnings;
			// System.out.println("New Bank: " + newBank);

			StringBuilder betNameR = new StringBuilder("");
			betNameR.append(" %-10s");
			System.out.printf(betNameR.toString(), betName());

			StringBuilder betAmountR = new StringBuilder("");
			betAmountR.append(" %10d");
			System.out.printf(betAmountR.toString(), betAmount);

			StringBuilder bankR = new StringBuilder("");
			bankR.append(" %10d");
			System.out.printf(bankR.toString(), bank);
			
			StringBuilder winR = new StringBuilder("");
			winR.append(" %10d");
			System.out.printf(winR.toString(), winnings);
			
			StringBuilder newBankR = new StringBuilder("");
			newBankR.append(" %10d \r");
			System.out.printf(newBankR.toString(), newBank);
			
		}

		 

	}

	private static String betName() {
		String[] bet = { "First", "Second", "Third", "Forth", "Fith", "Sixth",
				"Seventh", "Eigth", "Ninth", "Tenth" };
		count++;
		nameOfBet = bet[count];

		return nameOfBet;

	}

	private static int betChange() {
		switch (text) {
		case "UP":
			int diff = 0;

			int difference = diff + 10;

			return difference;
		case "DOWN":
			int downDiff = 0;

			int downDifference = downDiff - 10;

			return downDifference;
		case "DOUBLE":
			int douDiff = 0;

			int douDifference = douDiff + betAmount;

			return douDifference;
		default:
			
			int deDiff = 0;

			int deDifference = deDiff + 0;

			return deDifference;
			
		}
		
	}

}
