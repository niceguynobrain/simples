/* Take in words and display in list.
 * 
 * 	Display in alphabetical order.
 */

package wna.altervista.org;

import java.util.ArrayList;
import java.util.Scanner;





public class WordList {
	// Constructor
	
	

	
	
	
	

	public static void main(String[] args) {
//		String[] userInput = new String[];
////		System.out.println("Please add a word to the list: ");
////		userInput[0] = new Scanner(System.in).nextLine();
////		System.out.println("Please add a word to the list: ");
////		userInput[1] = new Scanner(System.in).nextLine();
////		System.out.println("Please add a word to the list: ");
////		userInput[2] = new Scanner(System.in).nextLine();
////		System.out.println("The second word is: " + userInput[1]);
//	
		
//		
//		ArrayList<WordList> list  = new ArrayList<WordList>();
//		
//		
//		System.out.println("Please enter a word: ");
//		userInput = new Scanner(System.in).nextLine();
//		WordList.add(userInput);
//		
//		
//		System.out.println("Please enter a word: ");
//		userInput = new Scanner(System.in).nextLine();
//		WordList.add(userInput);
//		
//		System.out.println(WordList);
//		
		
		// need to find out how to have unknown input into a list
//		and add new item to list (make list bigger dyamically.
//		also need for loop to iterate through each list item and print out.
		
		
		}







	private static void add(String userInput2) {
		// TODO Auto-generated method stub
		
	}
		
	}


