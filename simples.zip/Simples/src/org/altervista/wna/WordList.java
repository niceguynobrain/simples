/* Take in words and display in list.
 * 
 * 	Display in alphabetical order.
 * 
 * 	Known issue: aardvarks and aardark entered into the list results in aardvarks not showing up in alphabetised list.
 * I'm thinking there's probably a way round this that doesn't invovle extending out my multi-dimentional array to 10
 * Which suggests there's a better way of doing this whole thing, I'm just haven't learnt it yet.
 * 
 */

package org.altervista.wna;

import java.util.ArrayList;
import java.util.Scanner;

public class WordList {

	private static String userInput;
	private static int count;
	private static ArrayList<String> list;
	private static Scanner scr;
	private static String[][][] alphaList;
	private static String wordInList;
	private static int indexOfChar1;
	private static int indexOfChar2;
	private static int indexOfChar3;

	public static void main(String[] args) {
		// read list
		list = new ArrayList<String>();

		System.out.println("enter a word to put in the list: ");
		scr = new Scanner(System.in);
		while (true) {
			userInput = scr.nextLine();
			if (userInput.equals(""))
				break;
			list.add(userInput);
			count++;
		}
		;
		System.out.println("Number of words in list: " + count);
		System.out.println("Words in the list: " + list);

		alphaList = new String[100][100][100];

		// order list
		for (int i = 0; i < list.size(); i++) {
			wordInList = list.get(i).toString();

			// get firstletter of word
			Character order = wordInList.charAt(0);
			// convert to string
			String check = Character.toString(order);
			// get index
			int index = "0".compareTo(check);
			// invert minus scale
			indexOfChar1 = (-(index));

			Character charTwo = wordInList.charAt(1);
			String stringValueOfChar2 = Character.toString(charTwo);
			int minusScaleOfChar2 = "0".compareTo(stringValueOfChar2);
			indexOfChar2 = (-(minusScaleOfChar2));

			Character charThree = wordInList.charAt(2);
			String stringValueOfChar3 = Character.toString(charThree);
			int minusScaleOfChar3 = "0".compareTo(stringValueOfChar3);
			indexOfChar3 = (-(minusScaleOfChar3));

			alphaList[indexOfChar1][indexOfChar2][indexOfChar3] = wordInList;
		}

		System.out.println("\n List in alphabetical order: \n");

		for (int row = 0; row < alphaList.length; row++) {
			for (int col = 0; col < alphaList[row].length; col++) {
				for (int third = 0; third < alphaList[col].length; third++) {
					if (alphaList[row][col][third] != null)
						System.out.print(alphaList[row][col][third] + "\n");
				}
			}
		}
	}
}
