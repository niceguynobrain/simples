/* I want to create a simple program that takes in some text and returns it in a different font.
 * 
 */
package org.altervista.wna;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class FontManipulation {
	
	
	
	public static void main(String[] args) {

		userInput = JOptionPane.showInputDialog("What is your name?");
		BuildGUI();

	}

	
	
	private static String userInput;
	private static JFrame frame;
	private static JButton change;

	private static void BuildGUI() {
		frame = new JFrame();
		change = new JButton("Click to change the text  " + userInput);
		frame.setSize(300, 300);
		frame.add(change);

		change.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				changeFont();
			}
		});

		frame.setVisible(true);
	}

	private static void changeFont() {
		change.setText(userInput);
		// Change font
	}

	


}
